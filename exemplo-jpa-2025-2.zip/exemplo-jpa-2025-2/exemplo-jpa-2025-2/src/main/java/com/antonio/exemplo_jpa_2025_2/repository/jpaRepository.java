package com.antonio.exemplo_jpa_2025_2.repository;

public interface jpaRepository<T1, T2> {

}

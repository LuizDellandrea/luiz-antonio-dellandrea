package com.antonio.exemplo_jpa_2025_2.repository;

import com.antonio.exemplo_jpa_2025_2.entity.Departamento;

public interface DepartamentoRepository extends jpaRepository<Departamento, Integer>{

}

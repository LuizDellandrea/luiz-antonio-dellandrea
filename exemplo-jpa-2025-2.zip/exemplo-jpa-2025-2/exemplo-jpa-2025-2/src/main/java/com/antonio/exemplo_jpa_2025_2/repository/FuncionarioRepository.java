package com.antonio.exemplo_jpa_2025_2.repository;

import com.antonio.exemplo_jpa_2025_2.entity.Funcionario;

public interface FuncionarioRepository extends jpaRepository<Funcionario,Integer>{

}
